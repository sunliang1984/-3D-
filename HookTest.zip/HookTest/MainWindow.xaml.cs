﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace HookTest
{
    /// <summary>
    /// MainWindow.xaml 的交互逻辑
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();

            listener.Start();

            listener.ScanerEvent += Listener_ScanerEvent;

            this.Closed += (sender, e) =>
            {
                listener.Stop();
            };

            this.DataContext = this;
        }
        ScanerHook listener = new ScanerHook();

        private string scanerResult = "0";
        public string ScanerResult
        {
            get => scanerResult;
            set => scanerResult = value;
        }
        /// <summary>
        /// 注意需要也回车键结束
        /// </summary>
        /// <param name="codes"></param>
        private void Listener_ScanerEvent(ScanerHook.ScanerCodes codes)
        {
            this.tb_Result.Text = codes.Result;
        }
    }
}
